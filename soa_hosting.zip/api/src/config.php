<?php
	return[
		'determinateRouteBeforeAppMiddleware'=>false,
		'outputBuffering'=>false,
		'displayErrorDetails'=>true,
		'db'=>[
			"driver" 	=> "mysql",
			"host"		=> "localhost",
			"database"	=> "geoindos_user",
			"username"	=> "geoindos_user",
			"password"	=> "Cancan110796",
			"charset"	=> "utf8",
			"collation"	=> "utf8_general_ci"
		]
	];
