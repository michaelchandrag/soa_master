<?php
class Kabupatenku extends \Illuminate\Database\Eloquent\Model
{
	protected $table='Kabupatenku';
	protected $primaryKey = 'id_kab';
	public $timestamps = false;
	public $incrementing = false;
}