<?php
class Userku extends \Illuminate\Database\Eloquent\Model
{
	protected $table='Userku';
	public $timestamps = false;
	public $incrementing = false;
}