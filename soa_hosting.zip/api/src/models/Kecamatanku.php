<?php
class Kecamatanku extends \Illuminate\Database\Eloquent\Model
{
	protected $table='Kecamatanku';
	protected $primaryKey = 'id_kec';
	public $timestamps = false;
	public $incrementing = false;
}