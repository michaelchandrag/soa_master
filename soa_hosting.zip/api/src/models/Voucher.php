<?php
class Voucher extends \Illuminate\Database\Eloquent\Model
{
	protected $table='Voucher';
	public $timestamps = false;
	public $incrementing = false;
}