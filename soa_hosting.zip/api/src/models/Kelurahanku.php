<?php
class Kelurahanku extends \Illuminate\Database\Eloquent\Model
{
	protected $table='Kelurahanku';
	protected $primaryKey = 'id_kel';
	public $timestamps = false;
	public $incrementing = false;
}