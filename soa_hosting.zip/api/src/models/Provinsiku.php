<?php
class Provinsiku extends \Illuminate\Database\Eloquent\Model
{
	protected $table='Provinsiku';
	protected $primaryKey = 'id_prov';
	public $timestamps = false;
	public $incrementing = false;
}